#include "UIBase.h"



UIBase::UIBase()
{
}


UIBase::~UIBase()
{
}
